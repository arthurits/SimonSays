using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;
using System.Drawing.Drawing2D;
using Cpp.Diagram.Rounded;

namespace RoundedCorners
{
	/// <summary>
	/// Summary description for Form1.
	/// </summary>
	public class MainForm : System.Windows.Forms.Form
	{
		private System.Windows.Forms.PictureBox pbDraw;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public MainForm()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.pbDraw = new System.Windows.Forms.PictureBox();
			this.SuspendLayout();
			// 
			// pbDraw
			// 
			this.pbDraw.Location = new System.Drawing.Point(8, 8);
			this.pbDraw.Name = "pbDraw";
			this.pbDraw.Size = new System.Drawing.Size(464, 400);
			this.pbDraw.TabIndex = 0;
			this.pbDraw.TabStop = false;
			this.pbDraw.Paint += new System.Windows.Forms.PaintEventHandler(this.pbDraw_Paint);
			// 
			// MainForm
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(480, 421);
			this.Controls.Add(this.pbDraw);
			this.Name = "MainForm";
			this.Text = "Form1";
			this.ResumeLayout(false);

		}
		#endregion

		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main() 
		{
			Application.Run(new MainForm());
		}

		private void pbDraw_Paint(object sender, PaintEventArgs e)
		{
			GraphicsContainer containerState = e.Graphics.BeginContainer();
			e.Graphics.PageUnit = System.Drawing.GraphicsUnit.Millimeter;
			e.Graphics.SmoothingMode = System.Drawing.Drawing2D.SmoothingMode.AntiAlias;
			e.Graphics.Clear(Color.White);

			PointF[] butterfly = new PointF[9];
			butterfly[0].X = 10;
			butterfly[0].Y = 10;
			butterfly[1].X = 30;
			butterfly[1].Y = 20;
			butterfly[2].X = 50;
			butterfly[2].Y = 10;
			butterfly[3].X = 30;
			butterfly[3].Y = 30;
			butterfly[4].X = 50;
			butterfly[4].Y = 50;
			butterfly[5].X = 30;
			butterfly[5].Y = 40;
			butterfly[6].X = 10;
			butterfly[6].Y = 50;
			butterfly[7].X = 30;
			butterfly[7].Y = 30;
			butterfly[8].X = 10;
			butterfly[8].Y = 10;
			drawFigure(e, butterfly);

			PointF[] roundedRectangle = new PointF[5];
			roundedRectangle[0].X = 60;
			roundedRectangle[0].Y = 15;
			roundedRectangle[1].X = 100;
			roundedRectangle[1].Y = 15;
			roundedRectangle[2].X = 100;
			roundedRectangle[2].Y = 45;
			roundedRectangle[3].X = 60;
			roundedRectangle[3].Y = 45;
			roundedRectangle[4].X = 60;
			roundedRectangle[4].Y = 15;
			drawFigure(e, roundedRectangle);

			e.Graphics.EndContainer(containerState);

		}

		private static void drawFigure(PaintEventArgs e, PointF[] points)
		{
			GraphicsPath path = new GraphicsPath();
			path.AddLines(points);
			path.CloseFigure();
			drawPath(e, path, Color.Blue);
			path.Reset();

			Cpp.Diagram.Rounded.Corners r = new Cpp.Diagram.Rounded.Corners(points, 5);
			r.Execute(path);
			path.CloseFigure();
			Matrix matrix = new Matrix();
			matrix.Translate(0, 50);
			path.Transform(matrix);
			drawPath(e, path, Color.Red);
			path.Dispose();
		}

		private static void drawPath(PaintEventArgs e, GraphicsPath path, Color color)
		{
			LinearGradientBrush brush = new LinearGradientBrush(path.GetBounds(),
				color, Color.White, LinearGradientMode.Vertical);
			e.Graphics.FillPath(brush, path);
			Pen pen = new Pen(System.Drawing.Color.Black, 1);
			e.Graphics.DrawPath(pen, path);

			brush.Dispose();
			pen.Dispose();
		}
	}
}
