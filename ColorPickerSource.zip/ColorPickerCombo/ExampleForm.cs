﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Threading;
using LaMarvin.Windows.Forms;
using System.Diagnostics;

namespace ColorPickerCombo
{
    public partial class ExampleForm : Form
    {
        DataSet data;
        const string FileName="ColorData.xml";
        

        public ExampleForm()
        {
            InitializeComponent();
            this.FormClosed += new FormClosedEventHandler(Form1_FormClosed);
            data = new DataSet();
            LoadData(Application.StartupPath + @"\" + FileName );
            DataTable BSTable = data.Tables["ColorName"];
            LoadGridValuesFromTable(ref dataGridView1, BSTable);
            dataGridView1.Columns[0].HeaderText="Text";
            dataGridView1.Columns[1].HeaderText="Color";
        }

        void Form1_FormClosed(object sender, FormClosedEventArgs e)
        {
            DataTable NewData;
            data.Tables.Remove("ColorName");
            NewData = SaveGridValuesToDataTable(dataGridView1, "ColorName");
            data.Tables.Add(NewData);
            data.WriteXml(FileName);            
        }

        private void LoadData(string lclFileName)
        {
            data.ReadXml(lclFileName);
        }

        //Save the grid values to DataTable and return this table
        private DataTable SaveGridValuesToDataTable(DataGridView dv,string DataTableName)
        {
            DataColumn NewColumn;
            DataTable ConnectionsTable = new DataTable(DataTableName);
            
            int NumOfColumns = dv.Columns.Count;
            int NumOfRows = dv.Rows.Count;
            DataRow NewRow;
            for (int i=0; i<NumOfColumns;i++)
            {
                NewColumn = new DataColumn();
                NewColumn.DataType = System.Type.GetType("System.String");
                NewColumn.ColumnName = dv.Columns[i].Name;
                ConnectionsTable.Columns.Add(NewColumn);
            }
         
            for (int i = 0; i < NumOfRows-1; i++)
            {
                NewRow=ConnectionsTable.NewRow();
                for (int j = 0; j < NumOfColumns; j++)
                {
                    if (dv.Rows[i].Cells[j].GetType()==typeof(ColorPickerCell))
                    {
                        ColorPickerCell ColorCell=(ColorPickerCell)dv.Rows[i].Cells[j];
                        Color TemoColor = (Color)dv.Rows[i].Cells[j].Value;
                        NewRow[j] = TemoColor.Name;
                        
                       
                    }
                    else
                        NewRow[j] = dv.Rows[i].Cells[j].Value;
                }
                ConnectionsTable.Rows.Add(NewRow);
            }
            return ConnectionsTable;
        }

        //Load the values from the DataTable and update the grid with those values.
        private void LoadGridValuesFromTable(ref DataGridView dv, DataTable data)
        {
            string value;
            Color lclColor;
            int result;
            DataGridViewTextBoxColumn TextColumn;
            ColorPickerColumn colColorPick = new ColorPickerColumn();
            colColorPick.Name = "Color";
            int CurrentColumnNumber;
            dv.SuspendLayout();
            foreach (DataColumn column in data.Columns)
            {
                if (column.ColumnName == "Color")
                    dv.Columns.Add(colColorPick);
                else
                {
                    TextColumn = new DataGridViewTextBoxColumn();
                    TextColumn.Name = column.ColumnName;
                    dv.Columns.Add(new DataGridViewTextBoxColumn());
                }
            }

            foreach (DataRow row in data.Rows)
            {
                CurrentColumnNumber = 0;
                int rownumber = dv.Rows.Add();
                foreach (DataColumn column in data.Columns)
                {
                    if (column.ColumnName == "Color")
                    {
                        value = row[CurrentColumnNumber].ToString();
                        if (int.TryParse(value, System.Globalization.NumberStyles.HexNumber, null, out result))
                            lclColor = Color.FromArgb(result);
                        else
                            lclColor = Color.FromName(value);
                        dv.Rows[rownumber].Cells[CurrentColumnNumber].Value = lclColor;
                    }
                    else
                    {
                        dv.Rows[rownumber].Cells[CurrentColumnNumber].Value = row[CurrentColumnNumber];
                    }
                    CurrentColumnNumber++;
                }
            }
            dv.ResumeLayout();
        }

        //Get a string containg a predefined system color name or a hex value and returns
        //an integer representing the RGB value of this color.
        public int ConvertColorNameToValue(string ColorName)
        {

            Color TempColor;
            int result;
            //Check if the string is a system color name or a Hex number
            if (int.TryParse(ColorName, System.Globalization.NumberStyles.HexNumber, null, out result))
                TempColor = Color.FromArgb(result);
            else
                //The string is a system color name
                TempColor = Color.FromName(ColorName);
            return TempColor.ToArgb();
        }

    }
}
